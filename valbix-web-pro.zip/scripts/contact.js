
document.getElementById('contactForm').addEventListener('submit', function(e) {
  e.preventDefault();
  alert('Gracias por contactar. Pronto te responderemos.');
});
